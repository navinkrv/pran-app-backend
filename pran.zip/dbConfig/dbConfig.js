module.exports={
    HOST:"198.251.89.164",
    USER:"dzyissjs_pranapi",
    PASSWORD:"Pran@official",
    DB:"dzyissjs_pranapi",
    dialect:"mysql",
    
    pool:{
            max:5,
            min:0,
            acquire:30000,
            idle:10000
    }
}