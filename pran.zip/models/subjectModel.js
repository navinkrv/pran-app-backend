module.exports=(sequelize,DataTypes)=>{
 
}